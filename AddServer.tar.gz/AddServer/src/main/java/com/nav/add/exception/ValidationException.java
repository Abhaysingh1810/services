package com.nav.add.exception;

public class ValidationException extends Exception {
	public ValidationException(String message) {
		super(message);
	}
}