package com.nav.add.addServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddServerApplication.class, args);
	}
}
